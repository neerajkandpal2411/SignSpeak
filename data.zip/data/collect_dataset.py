import cv2
import os
import numpy as np
import time
import mediapipe as mp

DATA_PATH = "data/processed_frames"
SEQUENCE_LENGTH = 30
SAMPLES_PER_GESTURE = 30

mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils

hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.7
)


def collect_gesture(gesture_name):
    gesture_path = os.path.join(DATA_PATH, gesture_name)
    os.makedirs(gesture_path, exist_ok=True)

    cap = cv2.VideoCapture(0)

    print(f"\nCollecting data for gesture: {gesture_name}")
    print("Get ready...")
    time.sleep(3)

    for sample in range(SAMPLES_PER_GESTURE):
        sequence = []
        print(f"Recording sample {sample + 1}/{SAMPLES_PER_GESTURE}")

        while len(sequence) < SEQUENCE_LENGTH:
            ret, frame = cap.read()
            if not ret:
                continue

            image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            image.flags.writeable = False
            results = hands.process(image)
            image.flags.writeable = True

            if results.multi_hand_landmarks:
                for hand in results.multi_hand_landmarks:
                    landmarks = []
                    for lm in hand.landmark:
                        landmarks.append([lm.x, lm.y, lm.z])

                    sequence.append(landmarks)
                    mp_draw.draw_landmarks(
                        frame, hand, mp_hands.HAND_CONNECTIONS
                    )

            cv2.putText(
                frame,
                f"{gesture_name} | Sample {sample + 1}",
                (10, 40),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 255, 0),
                2
            )

            cv2.imshow("Dataset Collection", frame)
            cv2.waitKey(1)

        np.save(
            os.path.join(gesture_path, f"seq_{sample:03d}.npy"),
            np.array(sequence)
        )

    cap.release()
    cv2.destroyAllWindows()
    print(f"Finished collecting gesture: {gesture_name}")


if __name__ == "__main__":
    gesture = input("Enter gesture name: ").strip().lower()
    collect_gesture(gesture)
